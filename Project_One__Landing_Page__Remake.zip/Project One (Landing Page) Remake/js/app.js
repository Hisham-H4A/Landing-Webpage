// define global variables
const secCol = document.querySelectorAll('section');
const secArray = Array.from(secCol);
const navBarList = document.querySelector('#navbar__list');
const topButton = document.getElementById('top-btn');

// build the nav
// created a loop that loops over all the sections and add a list item to each of them, and assigned the section Id so it can be scrollable!
function makeListItem() {
    for (section of secArray) {
        listItem = document.createElement('li');
        listItem.innerHTML = `<li><a href="#${section.id}" data-nav="${section.id}" class="menu__link">${section.dataset.nav}</a></li>`;
        navBarList.appendChild(listItem);
    }
}
// Scroll to anchor ID smoothly
navBarList.addEventListener('click', (goToSection) => {
    goToSection.preventDefault();
    if (goToSection.target.dataset.nav) {
        document
            .getElementById(`${goToSection.target.dataset.nav}`)
            .scrollIntoView({ behavior: "smooth" });
    }
});

function revealToTopBtn() {
    if (document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
        topButton.style.display = "block";
    }
    else {
        topButton.style.display = "none";
    }
}

// Add class 'active' to section when near top of viewport
window.onscroll = function () {
    document.querySelectorAll('section').forEach(function (act) {
        if (act.getBoundingClientRect().top >= -300 && act.getBoundingClientRect().top <= 250) {
            act.classList.add('your-active-class');
        } else {
            act.classList.remove('your-active-class');
        }
        revealToTopBtn();
    });
};

// To make the button go to the top of the page
function goToTop() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}

topButton.addEventListener('click', goToTop);
// End Main Functions


makeListItem();

