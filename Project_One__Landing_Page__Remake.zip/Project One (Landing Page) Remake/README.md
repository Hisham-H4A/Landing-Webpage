# This project is made by me: **Omar Wael**
## and this is my re-submission to the first project in *Udacity's Professional web-development course.*
________________________________________________________________________________________________________
What I made and implemented to the project:
> assigned every section to its own link using Javascript.
> added the links to the sections to the navbar of the page.
> made clicking the sections in the navbar scroll the page to the desired location.
  >> made the scrolling smooth using Javascript,
> created a button that scrolls you to the top of the page,
  >> this button will not appear untill you scroll a little down the start of the page.
> created a function that adds the (your active class) to the section you are looking at, 
  >> this section will be highlighted using Javascript and CSS for the styles.
________________________________________________________________________________________________________